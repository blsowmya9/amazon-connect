name = "vanitynumber"
from .wordify import *
from .helper import is_valid_phone_number, is_valid_vanity_number
