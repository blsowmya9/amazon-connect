import json
import vanitynumber
import uuid
import boto3

def lambda_handler(event, context):
    # customer_number = '1-866-386-6481'
    customer_number = event['Details']['ContactData']['CustomerEndpoint']['Address']

    customer_number = customer_number[-11:]

    print(customer_number)

    idIntial = uuid.uuid1()

    vanityId = idIntial.hex   

    client = boto3.client('dynamodb') 

    vanity_number1 = vanitynumber.all_wordifications(customer_number)

    numberList = []

    for number in vanity_number1:

        charCount = 0

        for ch in number:

            if ch.isalpha():
                charCount=charCount+1

        if charCount > 4:
            numberList.append(number)

    numberList=numberList[:5]
        
    print(numberList)

    if len(numberList) == 0:
        result = {
           "result" : 'Unable to Generate any Vanity number for the provided Custom Number'
        }
           
    else:
        client.put_item(
            TableName='test-table',
            Item={
                'id': {
                'S': vanityId
                },
                'customer_number': {
                'S': customer_number
                },
                'vanityNumberList': {
                'SS': numberList
                }
            }
        )
        result = {
            "result":"Success",
            "numberList": numberList
        }

    return result

